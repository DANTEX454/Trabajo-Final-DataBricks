from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.getOrCreate()

flights  = spark.table("workspace.bronze.flights")
airlines = spark.table("workspace.bronze.airlines")
airports = spark.table("workspace.bronze.airports")

orig = airports.select(F.col("airport_id").alias("origin_airport"),
                       F.col("city").alias("origin_city"),
                       F.col("country").alias("origin_country"))
dest = airports.select(F.col("airport_id").alias("destination_airport"),
                       F.col("city").alias("destination_city"),
                       F.col("country").alias("destination_country"))

silver = (flights
    .join(airlines.select("airline_id", "airline_name"), "airline_id", "left")
    .join(orig, "origin_airport", "left")
    .join(dest, "destination_airport", "left")
    .withColumn("delay_imputed",
                F.col("departure_delay").isNull() | F.col("arrival_delay").isNull())
    .fillna({"departure_delay": 0, "arrival_delay": 0})
    .withColumn("delay_total", F.col("departure_delay") + F.col("arrival_delay"))
    .withColumn("on_time", F.when(F.col("arrival_delay") <= 15, 1).otherwise(0))
    .withColumn("distance_km", F.round(F.col("distance_miles") * 1.60934, 2))
    .withColumn("delay_category",
        F.when(F.col("delay_total") <= 0, "None")
         .when(F.col("delay_total") <= 30, "Short")
         .when(F.col("delay_total") <= 90, "Medium")
         .otherwise("Long")))

def guardar(df, nombre):
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true").saveAsTable(f"workspace.silver.{nombre}"))

guardar(silver, "silver_flights")

guardar(silver.groupBy("airline_id", "airline_name").agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay"),
    F.round(F.sum("distance_km"), 2).alias("total_distance_km"),
    F.count("*").alias("num_flights"),
    F.round(F.avg("on_time") * 100, 2).alias("pct_on_time")),
    "silver_airline_metrics")

out = silver.groupBy("origin_airport").agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay_out"),
    F.round(F.avg("on_time") * 100, 2).alias("pct_on_time_out"),
    F.count("*").alias("flights_out"))
inc = silver.groupBy("destination_airport").agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay_in"),
    F.count("*").alias("flights_in"))
guardar(out.join(inc, out.origin_airport == inc.destination_airport, "full")
    .withColumn("airport_id", F.coalesce("origin_airport", "destination_airport"))
    .drop("origin_airport", "destination_airport"),
    "silver_airport_metrics")

print("silver_flights:", spark.table("workspace.silver.silver_flights").count(), "filas")