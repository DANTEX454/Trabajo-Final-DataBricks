# Databricks notebook source
for s in ["raw", "bronze", "silver", "gold"]:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS workspace.{s}")

spark.sql("CREATE VOLUME IF NOT EXISTS workspace.raw.csv_files")

# COMMAND ----------

from pyspark.sql import functions as F

flights = (spark.read
           .option("header", True)
           .csv("/Volumes/workspace/raw/csv_files/flights.csv"))

flights.printSchema()
print("Filas:", flights.count())
display(flights.limit(5))

# COMMAND ----------

flights = (flights
    .withColumn("flight_date", F.to_date("flight_date", "yyyy-MM-dd"))
    .withColumn("departure_delay", F.col("departure_delay").cast("double").cast("int"))
    .withColumn("arrival_delay", F.col("arrival_delay").cast("double").cast("int"))
    .withColumn("distance_miles", F.col("distance_miles").cast("int"))
)

flights.printSchema()

# COMMAND ----------

display(flights.select([
    F.sum(F.col(c).isNull().cast("int")).alias(c) for c in flights.columns
]))

# COMMAND ----------

antes = flights.count()
flights = flights.dropna(subset=["flight_id", "airline_id", "origin_airport"])
print("Filas eliminadas:", antes - flights.count())

# COMMAND ----------

# ingest_timestamp en flights
flights = flights.withColumn("ingest_timestamp", F.current_timestamp())

# airlines y airports: leer, quitar nulos en su ID y agregar timestamp
airlines = (spark.read.option("header", True)
            .csv("/Volumes/workspace/raw/csv_files/airlines.csv")
            .dropna(subset=["airline_id"])
            .withColumn("ingest_timestamp", F.current_timestamp()))

airports = (spark.read.option("header", True)
            .csv("/Volumes/workspace/raw/csv_files/airports.csv")
            .dropna(subset=["airport_id"])
            .withColumn("ingest_timestamp", F.current_timestamp()))

print("flights:", flights.count(), "| airlines:", airlines.count(), "| airports:", airports.count())
display(flights.limit(3))

# COMMAND ----------

for df, nombre in [(flights, "flights"), (airlines, "airlines"), (airports, "airports")]:
    (df.write.format("delta")
       .mode("overwrite")
       .option("overwriteSchema", "true")
       .saveAsTable(f"workspace.bronze.{nombre}"))

display(spark.sql("SHOW TABLES IN workspace.bronze"))

# COMMAND ----------

flights  = spark.table("workspace.bronze.flights")
airlines = spark.table("workspace.bronze.airlines")
airports = spark.table("workspace.bronze.airports")

flights.printSchema()
airlines.printSchema()
airports.printSchema()

# COMMAND ----------

# airports se une DOS veces (origen y destino), así que se prepara una versión para cada uno
orig = airports.select(
    F.col("airport_id").alias("origin_airport"),
    F.col("city").alias("origin_city"),
    F.col("country").alias("origin_country"))

dest = airports.select(
    F.col("airport_id").alias("destination_airport"),
    F.col("city").alias("destination_city"),
    F.col("country").alias("destination_country"))

enriched = (flights
    .join(airlines.select("airline_id", "airline_name"), "airline_id", "left")
    .join(orig, "origin_airport", "left")
    .join(dest, "destination_airport", "left"))

display(enriched.limit(5))
print("Filas:", enriched.count())

# COMMAND ----------

cols = ["flight_date", "airline_name", "origin_city", "destination_city",
        "departure_delay", "arrival_delay", "distance_miles"]

display(enriched.select([
    F.sum(F.col(c).isNull().cast("int")).alias(c) for c in cols
]))

# COMMAND ----------

enriched = (enriched
    .withColumn("delay_imputed",
                F.col("departure_delay").isNull() | F.col("arrival_delay").isNull())
    .fillna({"departure_delay": 0, "arrival_delay": 0}))

print("Filas imputadas:", enriched.filter("delay_imputed").count())

# COMMAND ----------

silver = (enriched
    .withColumn("delay_total", F.col("departure_delay") + F.col("arrival_delay"))
    .withColumn("on_time", F.when(F.col("arrival_delay") <= 15, 1).otherwise(0))
    .withColumn("distance_km", F.round(F.col("distance_miles") * 1.60934, 2))
    .withColumn("delay_category",
        F.when(F.col("delay_total") <= 0, "None")
         .when(F.col("delay_total") <= 30, "Short")
         .when(F.col("delay_total") <= 90, "Medium")
         .otherwise("Long")))

display(silver.limit(10))
display(silver.groupBy("delay_category").count().orderBy("count", ascending=False))

# COMMAND ----------

airline_metrics = (silver.groupBy("airline_id", "airline_name").agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay"),
    F.round(F.sum("distance_km"), 2).alias("total_distance_km"),
    F.count("*").alias("num_flights"),
    F.round(F.avg("on_time") * 100, 2).alias("pct_on_time")))

display(airline_metrics.orderBy("avg_delay"))

# % de vuelos a tiempo por aerolínea Y aeropuerto de origen
airline_origin_ontime = (silver.groupBy("airline_name", "origin_airport").agg(
    F.round(F.avg("on_time") * 100, 2).alias("pct_on_time"),
    F.count("*").alias("num_flights")))

display(airline_origin_ontime.orderBy("airline_name", "origin_airport"))

# COMMAND ----------

# Salientes: agrupamos por origen
out = silver.groupBy("origin_airport").agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay_out"),
    F.round(F.avg("on_time") * 100, 2).alias("pct_on_time_out"),
    F.count("*").alias("flights_out"))

# Entrantes: agrupamos por destino
inc = silver.groupBy("destination_airport").agg(
    F.round(F.avg("delay_total"), 2).alias("avg_delay_in"),
    F.count("*").alias("flights_in"))

# Se unen con "full" para no perder ningún aeropuerto
airport_metrics = (out.join(inc, out.origin_airport == inc.destination_airport, "full")
    .withColumn("airport_id", F.coalesce("origin_airport", "destination_airport"))
    .drop("origin_airport", "destination_airport"))

display(airport_metrics.orderBy("airport_id"))

# COMMAND ----------

display(silver.select([
    F.sum(F.col(c).isNull().cast("int")).alias(c) for c in silver.columns]))

# COMMAND ----------

def guardar(df, nombre, esquema):
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true")
       .saveAsTable(f"workspace.{esquema}.{nombre}"))

guardar(silver, "silver_flights", "silver")
guardar(airline_metrics, "silver_airline_metrics", "silver")
guardar(airport_metrics, "silver_airport_metrics", "silver")

display(spark.sql("SHOW TABLES IN workspace.silver"))

# COMMAND ----------

from pyspark.sql import Window

silver = spark.table("workspace.silver.silver_flights")

tiempo = (silver
    .withColumn("month", F.month("flight_date"))
    .withColumn("dow", F.dayofweek("flight_date"))
    .withColumn("dow_name", F.date_format("flight_date", "E"))
    .withColumn("quarter", F.quarter("flight_date")))

prom = F.round(F.avg("delay_total"), 2).alias("avg_delay")

display(tiempo.groupBy("month").agg(prom).orderBy("month"))
display(tiempo.groupBy("dow", "dow_name").agg(prom).orderBy("dow"))
display(tiempo.groupBy("quarter").agg(prom).orderBy("quarter"))

# COMMAND ----------

w_rn = Window.partitionBy("airline_id").orderBy(F.col("delay_total").desc(), "flight_id")
w_dr = Window.partitionBy("airline_id").orderBy(F.col("delay_total").desc())

ranked = (silver
    .withColumn("rn", F.row_number().over(w_rn))
    .withColumn("dr", F.dense_rank().over(w_dr)))

display(ranked.filter("rn <= 5")
        .select("airline_id", "flight_id", "delay_total", "rn", "dr")
        .orderBy("airline_id", "rn"))

display(ranked.filter("dr <= 5").groupBy("airline_id").count()
        .withColumnRenamed("count", "filas_dr_hasta_5"))

# COMMAND ----------

airport_rank = (silver.groupBy("origin_airport", "origin_city")
    .agg(F.round(F.avg("delay_total"), 2).alias("avg_delay"))
    .withColumn("airport_rank",
                F.dense_rank().over(Window.orderBy(F.col("avg_delay").desc()))))
display(airport_rank.orderBy("airport_rank"))

airline_month = (tiempo.groupBy("airline_name", "month").agg(
    prom,
    F.round(F.avg("on_time") * 100, 2).alias("pct_on_time"),
    F.count("*").alias("num_flights")))
display(airline_month.orderBy("airline_name", "month"))

# COMMAND ----------

guardar(airport_rank, "analytics_airport_rank", "silver")
guardar(airline_month, "analytics_airline_month", "silver")

airport_rank.createOrReplaceTempView("v_airport_rank")
airline_month.createOrReplaceTempView("v_airline_month")

display(spark.sql("SELECT * FROM v_airline_month ORDER BY pct_on_time DESC LIMIT 5"))

# COMMAND ----------

silver = spark.table("workspace.silver.silver_flights")

# a) Retraso promedio por aerolínea y aeropuerto de origen, por mes
gold_delay = (silver
    .withColumn("year_month", F.date_format("flight_date", "yyyy-MM"))
    .groupBy("year_month", "airline_id", "airline_name", "origin_airport")
    .agg(F.round(F.avg("delay_total"), 2).alias("avg_delay"),
         F.count("*").alias("num_flights")))

# b) Ranking de aeropuertos más puntuales (1 = más puntual)
gold_rank = (silver.groupBy("origin_airport", "origin_city")
    .agg(F.round(F.avg("on_time") * 100, 2).alias("pct_on_time"),
         F.round(F.avg("delay_total"), 2).alias("avg_delay"),
         F.count("*").alias("num_flights"))
    .withColumn("punctuality_rank",
                F.dense_rank().over(Window.orderBy(F.col("pct_on_time").desc()))))

# c) KPI de % de vuelos a tiempo por aerolínea
gold_kpi = (silver.groupBy("airline_id", "airline_name")
    .agg(F.round(F.avg("on_time") * 100, 2).alias("pct_on_time"),
         F.count("*").alias("num_flights")))

display(gold_rank.orderBy("punctuality_rank"))
display(gold_kpi.orderBy(F.desc("pct_on_time")))

# COMMAND ----------

gold_feat = silver.select(
    "flight_id", "flight_date",
    F.month("flight_date").alias("flight_month"),
    F.dayofweek("flight_date").alias("flight_dow"),
    "airline_id", "origin_airport", "destination_airport",
    "distance_km", "departure_delay", "arrival_delay", "delay_imputed")

# COMMAND ----------

guardar(gold_delay, "gold_delay_airline_airport_month", "gold")
guardar(gold_rank, "gold_airport_punctuality_ranking", "gold")
guardar(gold_kpi, "gold_airline_ontime_kpi", "gold")
guardar(gold_feat, "gold_flights_features", "gold")

display(spark.sql("SHOW TABLES IN workspace.gold"))

# COMMAND ----------

tablas = [("gold_delay_airline_airport_month", "airline_name, origin_airport"),
          ("gold_airport_punctuality_ranking", "origin_airport"),
          ("gold_airline_ontime_kpi", "airline_id"),
          ("gold_flights_features", "airline_id, origin_airport")]

for t, cols in tablas:
    spark.sql(f"OPTIMIZE workspace.gold.{t} ZORDER BY ({cols})")

display(spark.sql("DESCRIBE HISTORY workspace.gold.gold_delay_airline_airport_month"))