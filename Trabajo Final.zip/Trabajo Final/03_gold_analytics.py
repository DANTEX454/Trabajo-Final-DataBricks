from pyspark.sql import SparkSession, Window, functions as F

spark = SparkSession.builder.getOrCreate()
silver = spark.table("workspace.silver.silver_flights")

def guardar(df, nombre):
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true").saveAsTable(f"workspace.gold.{nombre}"))

guardar(silver.withColumn("year_month", F.date_format("flight_date", "yyyy-MM"))
    .groupBy("year_month", "airline_id", "airline_name", "origin_airport")
    .agg(F.round(F.avg("delay_total"), 2).alias("avg_delay"),
         F.count("*").alias("num_flights")),
    "gold_delay_airline_airport_month")

guardar(silver.groupBy("origin_airport", "origin_city")
    .agg(F.round(F.avg("on_time") * 100, 2).alias("pct_on_time"),
         F.round(F.avg("delay_total"), 2).alias("avg_delay"),
         F.count("*").alias("num_flights"))
    .withColumn("punctuality_rank",
                F.dense_rank().over(Window.orderBy(F.col("pct_on_time").desc()))),
    "gold_airport_punctuality_ranking")

guardar(silver.groupBy("airline_id", "airline_name")
    .agg(F.round(F.avg("on_time") * 100, 2).alias("pct_on_time"),
         F.count("*").alias("num_flights")),
    "gold_airline_ontime_kpi")

guardar(silver.select("flight_id", "flight_date",
    F.month("flight_date").alias("flight_month"),
    F.dayofweek("flight_date").alias("flight_dow"),
    "airline_id", "origin_airport", "destination_airport",
    "distance_km", "departure_delay", "arrival_delay", "delay_imputed"),
    "gold_flights_features")

for t, cols in [("gold_delay_airline_airport_month", "airline_name, origin_airport"),
                ("gold_airport_punctuality_ranking", "origin_airport"),
                ("gold_airline_ontime_kpi", "airline_id"),
                ("gold_flights_features", "airline_id, origin_airport")]:
    spark.sql(f"OPTIMIZE workspace.gold.{t} ZORDER BY ({cols})")

print("Gold listo")