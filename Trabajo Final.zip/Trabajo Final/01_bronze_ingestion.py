from pyspark.sql import SparkSession, functions as F

spark = SparkSession.builder.getOrCreate()
RAW = "/Volumes/workspace/raw/csv_files"

def leer(nombre):
    return spark.read.option("header", True).csv(f"{RAW}/{nombre}.csv")

flights = (leer("flights")
    .withColumn("flight_date", F.to_date("flight_date", "yyyy-MM-dd"))
    .withColumn("departure_delay", F.col("departure_delay").cast("double").cast("int"))
    .withColumn("arrival_delay", F.col("arrival_delay").cast("double").cast("int"))
    .withColumn("distance_miles", F.col("distance_miles").cast("int"))
    .dropna(subset=["flight_id", "airline_id", "origin_airport"])
    .withColumn("ingest_timestamp", F.current_timestamp()))

airlines = (leer("airlines").dropna(subset=["airline_id"])
    .withColumn("ingest_timestamp", F.current_timestamp()))
airports = (leer("airports").dropna(subset=["airport_id"])
    .withColumn("ingest_timestamp", F.current_timestamp()))

for df, nombre in [(flights, "flights"), (airlines, "airlines"), (airports, "airports")]:
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true").saveAsTable(f"workspace.bronze.{nombre}"))
    print(f"bronze.{nombre}: {df.count()} filas")