# Databricks notebook source
import pandas as pd, numpy as np, matplotlib.pyplot as plt
import mlflow, mlflow.sklearn
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

df = (spark.table("workspace.gold.gold_flights_features")
      .filter("delay_imputed = false")
      .toPandas())

num = ["flight_month", "flight_dow", "distance_km", "departure_delay"]
cat = ["airline_id", "origin_airport", "destination_airport"]
X, y = df[num + cat], df["arrival_delay"]
print(df.shape)

# COMMAND ----------

X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
    X, y, df.index, test_size=0.2, random_state=42)
print(len(X_train), len(X_test))

# COMMAND ----------

baseline = DummyRegressor(strategy="mean").fit(X_train, y_train)

prep = ColumnTransformer(
    [("cat", OneHotEncoder(handle_unknown="ignore"), cat)],
    remainder="passthrough")

tree = Pipeline([
    ("prep", prep),
    ("model", DecisionTreeRegressor(max_depth=6, min_samples_leaf=50, random_state=42))
]).fit(X_train, y_train)

# COMMAND ----------

def metricas(m):
    p = m.predict(X_test)
    return mean_absolute_error(y_test, p), np.sqrt(mean_squared_error(y_test, p))

mae_b, rmse_b = metricas(baseline)
mae_t, rmse_t = metricas(tree)

res = pd.DataFrame({
    "modelo": ["Referencia (promedio)", "Árbol de regresión"],
    "MAE": [mae_b, mae_t],
    "RMSE": [rmse_b, rmse_t]})
display(res)

# COMMAND ----------

pred = tree.predict(X_test)

plt.figure(figsize=(6, 6))
plt.scatter(y_test, pred, alpha=0.2, s=8)
lim = [y_test.min(), y_test.max()]
plt.plot(lim, lim, "r--", label="Predicción perfecta")
plt.xlabel("arrival_delay real (min)")
plt.ylabel("arrival_delay predicho (min)")
plt.title("Árbol de regresión: real vs predicho")
plt.legend()
plt.show()

# COMMAND ----------

nombres = tree.named_steps["prep"].get_feature_names_out()
imp = pd.Series(tree.named_steps["model"].feature_importances_, index=nombres)
display(imp.sort_values(ascending=False).head(8).reset_index().rename(columns={"index": "variable", 0: "importancia"}))

# COMMAND ----------

salida = df.loc[idx_test, ["flight_id"]].copy()
salida["arrival_delay_real"] = y_test.values
salida["arrival_delay_pred"] = pred

(spark.createDataFrame(salida).write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true").saveAsTable("workspace.gold.ml_predictions"))
(spark.createDataFrame(res).write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true").saveAsTable("workspace.gold.ml_metrics"))

with mlflow.start_run(run_name="decision_tree_arrival_delay"):
    mlflow.log_params({"max_depth": 6, "min_samples_leaf": 50, "test_size": 0.2})
    mlflow.log_metrics({"mae": mae_t, "rmse": rmse_t,
                        "baseline_mae": mae_b, "baseline_rmse": rmse_b})
    mlflow.sklearn.log_model(tree, "model", input_example=X_test.head(5))

print("Guardado y registrado en MLflow")

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Interpretación de resultados
# MAGIC
# MAGIC **Objetivo y comparación.** Se entrenó un árbol de regresión para estimar el retraso de llegada de los vuelos (`arrival_delay`) y se comparó contra una referencia que siempre predice el promedio de los datos de entrenamiento. Ambos modelos se evaluaron con MAE y RMSE sobre el 20 % de los vuelos que no se usó para entrenar.
# MAGIC
# MAGIC **Resultados.** La referencia obtuvo un MAE de 18,21 minutos y un RMSE de 22,92 minutos. El árbol de regresión obtuvo un MAE de 8,08 minutos y un RMSE de 10,10 minutos. Esto equivale a una reducción del error de alrededor del 56 % en ambas métricas, por lo que el modelo aprendió un patrón real y no se limita a repetir el promedio. En promedio, la predicción del árbol se equivoca por unos 8 minutos.
# MAGIC
# MAGIC **Gráfico de predicciones contra valores reales.** Los puntos se agrupan alrededor de la línea de predicción perfecta, lo que indica que las predicciones son cercanas a los valores reales. Se observan franjas horizontales porque un árbol de profundidad limitada solo puede producir un número finito de valores distintos, uno por cada hoja. En los retrasos más extremos el modelo tiende a subestimar, es decir, predice valores más cercanos al promedio que los reales.
# MAGIC
# MAGIC **Variables utilizadas.** El modelo usó el retraso de salida (`departure_delay`), la distancia, el mes, el día de la semana, la aerolínea y los aeropuertos de origen y destino. El retraso de salida es una variable válida para predecir, porque se conoce antes de que el avión aterrice, y es razonable que tenga un peso importante: un vuelo que sale tarde suele llegar tarde.
# MAGIC
# MAGIC **Limitaciones y mejoras.** Se limitó la profundidad del árbol (6 niveles) y se exigió un mínimo de 50 vuelos por hoja para evitar que memorice los datos, a costa de perder precisión en los casos extremos. Como mejoras se podrían probar modelos más potentes como Random Forest o Gradient Boosting, ajustar los hiperparámetros con validación cruzada y agregar variables que hoy no existen en los datos, como el clima o la hora del vuelo.
# MAGIC
# MAGIC **Conclusión.** El árbol de regresión mejora de forma clara a la referencia y es útil para estimar el retraso de llegada, aunque su precisión disminuye en retrasos muy grandes.